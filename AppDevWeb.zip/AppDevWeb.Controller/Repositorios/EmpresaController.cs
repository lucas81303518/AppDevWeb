﻿using AppDevWeb.Modelo.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDevWeb.Controller.Repositorios
{
    public class EmpresaController
    {
        public List<Empresa> Empresas = new List<Empresa>();
        public Empresa emp = new Empresa();
       
        public void SalvarEmpresa(Empresa Emp)
        {
            if (GetEmpresa(Emp.CNPJ) == null)
                Empresas?.Add(Emp);
            else
                foreach (Empresa empresa in Empresas)
                    if (empresa.CNPJ == Emp.CNPJ)
                    {
                        empresa.NomeFantasia = Emp.NomeFantasia;
                        empresa.RazaoSocial = Emp.RazaoSocial;
                       
                    }
                    
        }

        public List<Empresa> GetEmpresas()
        {            
            return Empresas;
        }

        public void RemoverEmpresa(long CNPJ)
        {
            Empresas = Empresas.Where(o => o.CNPJ != CNPJ)
                               .ToList();
        }

        public Empresa GetEmpresa(long CNPJ)
        {
            return Empresas.FirstOrDefault(o => o.CNPJ == CNPJ);
        }
    }
}
