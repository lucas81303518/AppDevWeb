﻿using AppDevWeb.Modelo.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDevWeb.Controller.Repositorios
{
    public class FilialControllers
    {

        public Empresa empresa = new Empresa();//Instanciando Empresa para ter acesso a lista de Filiais


        public void Salvar(Filial Fil)
        {
            if (GetFilial(Fil.CNPJ) == null)
                empresa.Filiais?.Add(Fil);
            
            else
                foreach (Filial filial in empresa.Filiais)
                    if (filial.CNPJ == Fil.CNPJ)
                    {
                        filial.IE = Fil.IE;
                        filial.Descricao = Fil.Descricao;
                     
                    }
                   
        }

        public List<Filial> GetFiliais()
        {
            return empresa.Filiais;
        }

        public void RemoverFilial(long CNPJ)
        {
            empresa.Filiais = empresa.Filiais.Where(o => o.CNPJ != CNPJ)
                               .ToList();
        }

        public Filial GetFilial(long CNPJ)
        {
            return empresa.Filiais.FirstOrDefault(o => o.CNPJ == CNPJ);
        }
    }
}
