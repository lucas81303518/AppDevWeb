﻿function salvarFilial() {
    $.ajax({
        type: "POST",
        url: "https://localhost:44332/API/Filiais.asmx/SalvarFilial",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            limparCamposFiliais();
            carregarFiliais();
        },
        failure: function (msg) { alert(msg); },
        data: JSON.stringify({
            fil: {
                CNPJ: $("#ovTXT_CNPJFilial").val(),
                IE: $("#ovTXT_IE").val(),
                Descricao: $("#ovTXT_DescricaoFilial").val()
            },
        })
    });
}

function limparCamposFiliais() {
    $("#ovTXT_CNPJFilial").val("");
    $("#ovTXT_IE").val("");
    $("#ovTXT_DescricaoFilial").val("");

}

function carregarFiliais() {
    $.ajax({
        type: "GET",
        url: "https://localhost:44332/API/Filiais.asmx/ListarFiliais",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            $("#grid_filiais tbody").html("");
            var Filiais = data.d;
            for (var i = 0; i < Filiais.length; i++) {
                $("#grid_filiais tbody").append("<tr>" +
                    "<td>" + Filiais[i].CNPJ + "</td>" +
                    "<td>" + Filiais[i].IE + "</td>" +
                    "<td>" + Filiais[i].Descricao + "</td>" +
                    "<td>" +
                    " <button type='button' " +
                    "         class='btn btn-outline-primary btn-editar_fil' " +
                    "         data-codigo='" + Filiais[i].CNPJ + "'" +
                    ">Editar</button> " +
                    " <button type='button' " +
                    "         class='btn btn-outline-danger btn-remover_fil' " +
                    "         data-codigo='" + Filiais[i].CNPJ + "'" +
                    ">Remover</button > " +
                    "</td > " +
                    "</tr>");
            }
            adicionaEventoEditarFilial();
            adicionaEventoRemoverFilial();
        },
        failure: function (msg) { alert(msg); },
        data: {}
    });
}

function adicionaEventoEditarFilial() {
    $(document).on("click", ".btn-editar_fil", function () {
        var codigo = $(this).data("codigo");
        $.ajax({
            type: "POST",
            url: "https://localhost:44332/API/Filiais.asmx/GetFilial",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var Filial = data.d;
                $("#ovTXT_CNPJFilial").val(Filial.CNPJ);
                $("#ovTXT_IE").val(Filial.IE);
                $("#ovTXT_DescricaoFilial").val(Filial.Descricao);
              
            },
            failure: function (msg) { alert(msg); },
            data: JSON.stringify({ CNPJ: codigo })
        });
    });
}

function adicionaEventoRemoverFilial() {
    $(document).on("click", ".btn-remover_fil", function () {
        var codigo = $(this).data("codigo");
        $.ajax({
            type: "POST",
            url: "https://localhost:44332/API/Filiais.asmx/RemoverFilial",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                carregarFiliais();
            },
            failure: function (msg) { alert(msg); },
            data: JSON.stringify({ CNPJ: codigo })
        });
    });
}

$(document).ready(function () {
    carregarFiliais();

    $(document).on("click", "#btn_salvar_filial", salvarFilial);
});