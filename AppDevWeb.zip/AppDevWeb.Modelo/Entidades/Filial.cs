﻿using System.Collections.Generic;

namespace AppDevWeb.Modelo.Entidades
{
    public class Filial
    {
        public long CNPJ { get; set; }
        public string IE { get; set; }
        public string Descricao { get; set; }


        public Filial()
        {
        }
    }
}